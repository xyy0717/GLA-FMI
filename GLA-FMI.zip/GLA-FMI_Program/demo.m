clc
clear
load('Yeast.mat')
addpath(genpath('.\'));
train_label(train_label==-1)=0;
test_label(test_label==-1)=0;
[m,n]=size(train_data);
[~,l]=size(train_label);
train_data = columnMinMaxNormalization(train_data);
test_data = columnMinMaxNormalization(test_data);
%%计算单个标签的对应相似度矩阵
for i = 1:l
    Lfm{i} = cfuzzyl(train_label(:,i));
end

%%计算单个特征的对应相似度矩阵
for i =1:n
    Ffm{i} = cfuzzyf(train_data(:,i));
end


%%计算单个标签，特征的信息量
%计算标签信息量
HL=zeros(1,l);
for i=1:l
    HL(i)=cH(Lfm{i});
end
%计算特征信息量
HF=zeros(1,l);
for i=1:n
    HF(i)=cH(Ffm{i});
end

%计算特征-特征的联合信息量
JHFF = diag(HF);
for i = 1:n
    for j = i+1:n
        sim = cJH(Ffm{i}, Ffm{j});
        JHFF(i,j) = sim;
        JHFF(j,i) = sim;  % 对称赋值
    end
end

%计算特征-标签的联合信息量
JHFL = zeros(n,l);
for i = 1:n
    for j = 1:l
        JHFL(i,j) = cJH(Ffm{i}, Lfm{j});
    end
end

%计算标签-标签的联合信息量
JHLL = diag(HL);
for i = 1:l
    for j = i+1:l
        sim = cJH(Lfm{i}, Lfm{j});
        JHLL(i,j) = sim;
        JHLL(j,i) = sim;  % 对称赋值
    end
end

%%计算三个关系（标签-标签，特征-标签，特征-特征）（归一化信息和非归一化信息都保存）
%%计算标签之间的关系
HLsum = HL + HL';           % 构造 HL(i) + HL(j)，自动广播为 l×l 矩阵
R = HLsum - JHLL;           % 计算 R(i,j)
HLsum(HLsum == 0) = eps;
RN = 2 * R ./ HLsum;        % 计算 RN(i,j)

%%计算特征-标签之间的关系
HFLsum = HF' + HL;           % 自动广播为 n×l 矩阵
U = HFLsum - JHFL;          % U(i,j) = HF(i) + HL(j) - JHFL(i,j)
HFLsum(HFLsum == 0) = eps;
UN = 2 * U ./ HFLsum;       % UN(i,j) = 2 * U(i,j) / (HF(i) + HL(j))

%%计算特征-特征之间的关系
HFsum = HF + HF';           % 构造 HF(i) + HF(j)，自动广播为 n×n 矩阵
V = HFsum - JHFF;           % 计算 V(i,j)
HFsum(HFsum == 0) = eps;
VN = 2 * V ./ HFsum;        % 计算 VN(i,j)


%%计算标签权重
lw = compute_LW(RN);   %维度是 标签数*1

%%计算特征重要性向量
g = UN*lw;

%%实例参数
alpha=1;
beta=1;
gamma=1;
r_list = 1;

%%选择特征选择百分比
if n<=100
    Theta = 0.4;
elseif n<=500
    Theta = 0.3;
elseif n<=1000
    Theta = 0.2;
else
    Theta = 0.1;
end

k=fix(Theta*n);
[W, s, obj] = GLAFMI(k, VN, g, lw, train_data, train_label,alpha,beta,gamma,r_list);
f = find(s == 1);%%%
train_label(train_label==0)=-1;
test_label(test_label==0)=-1;
[Prior,PriorN,Cond,CondN]=MLKNN_train(train_data(:,f),train_label',10,1);
[HammingLoss,RankingLoss,Coverage,Average_Precision,macrof1,microf1,OneError,Outputs,Pre_Labels]=...
    MLKNN_test(train_data(:,f),train_label',test_data(:,f),test_label',10,Prior,PriorN,Cond,CondN);

