function [ W, s, obj ] = GLAFMI(k, R, g, lw, X, Y, alpha, beta, gamma, r1, r2)
%%输入   k：选择的特征数量   R：特征冗余矩阵  g：特征重要度向量（列向量） lw：标签重要性向量（行列不论）   X：特征矩阵，维度为样本*特征
%%       Y：标签矩阵，维度为样本*标签  alpha,beta,gamma：平衡参数    r1,r2：超参，默认相等，取值范围(0,2]
%%输出   W：权重向量   s：自适应特征激活向量（实现特征选择，列向量）   obj：目标函数值变化趋势
%%Written by Xie Hao on April 15, 2025
if nargin < 11
    r2 = r1;  % 如果没有提供 r2，则默认设置为 r1
end
[~,n_fea]= size(X);
n_lab = size(Y,2);

%%预备阶段（加速计算）
R = R - diag(diag(R));
c = max(eig(R));
Im = eye(n_fea);
f0 = 2*alpha*(c*Im-R);
gr2 = gamma*g.^r2;

%%随机初始化步骤
W = rand(n_fea, n_lab);

%%根据gr2初始化s
[~, idx] = sort(gr2, 'descend'); % 对 gr2 进行降序排序，得到索引
s = zeros(size(g));          % 初始化列向量 s（与 g 同大小）
s(idx(1:k)) = 1;             % 将前 k 个最大值的位置设为 1



XY = X'*Y;
XX = X'*X;

iter = 1; obji = 1;

while iter<31
    %%Update s
    W_norms = vecnorm(W, 2, 2);
    theta = W_norms .^ r1;
    f = f0*s+beta*theta+gr2;
    
    [~, idx] = sort(f, 'descend');  % 排序并获得索引
    s = zeros(size(f));
    s(idx(1:k)) = 1;
    
    %%Update W
    d = (r1 * (1 - s)) ./ (2 * (vecnorm(W, 2, 2).^2 + eps).^(1 - r1/2));
    D = diag(d);
    for j = 1:n_lab
        % 计算当前列的权重矩阵
        theta_j = lw(j); % 取对角线上的元素
        
        % 右侧：X^T * Y(:,j) * theta_j
        right_side = X' * theta_j * Y(:, j);
        
        % 左侧：X^T * X * theta_j + beta * D
        left_side = XX * theta_j + beta * D;
        left_side(left_side == 0) = eps;
        
        % 更新当前列的 W_j
        W(:, j) = pinv(left_side) * right_side;  % 求解线性方程
    end
    

    
    %%损失函数计算
    obj(iter) = compute_losslw(X, W, Y, s, R, lw, g, alpha, beta, gamma, r1, r2);
    if iter>1 && obj(iter)>obj(iter-1)
        biao=1;
    end
    cver = abs((obj(iter) - obji)/obji);
    obji = obj(iter);
    iter = iter + 1;
    if (cver < 10^-4 && iter > 3)
        disp(['迭代次数iter:',num2str(iter-1)])
        break;
    end
end
end