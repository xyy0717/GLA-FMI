function w = compute_LW(A,alpha,pr)
%% A:预先输入的标签相关性矩阵  alpha:阻尼因子（默认0.85）  pr:PageRank权重向量(默认ones(n, 1) / n,n表示标签数量）
    n = size(A,1);
    if nargin < 2, alpha = 0.85; end
    if nargin < 3, pr = ones(n, 1) / n; end
    A = A - diag(diag(A));      % 将对角线元素置为0，避免自环
    A_exp = exp(A) - 1;      % 指数变换并减1
    colSums = sum(A_exp, 1); % 按列求和
    zeroCols = (colSums < eps);  % 找出列和为0的点，避免后续出现问题
    P = A_exp ./ (colSums + zeroCols);    % 归一化，加上 zeroCols 是为了避免除0警告
    P(:, zeroCols) = 1 / n;
    
    w = (1 - alpha) * ((eye(n) - alpha * P) \ pr);    %闭式解，无需递归
end
