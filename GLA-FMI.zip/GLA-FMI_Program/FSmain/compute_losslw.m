function loss = compute_losslw(X, W, Y, s, R, lw, g, alpha, beta, gamma, r1, r2)
    %s:m*1,表示自适应特征激活向量
    %R:m*m,表示特征冗余矩阵
    %lw:标签重要度向量（行列不论）
    %g:m*1,表示加权特征显著性向量
    %alpha,beta,gamma:平衡参数
    %r1,r2:超参，一般来说，r1=r2
    % 第一项：平方 Frobenius 范数
    Theta_sqrt = diag(sqrt(lw));
    loss1 =norm((X * W - Y) * Theta_sqrt, 'fro')^2;

    % 第二项：s^T * R * s
    loss2 = alpha * (s' * R * s);

    % 第三项：beta * sum((1 - s_i) * norm(W_i, 2)^r1)
    one_minus_s = 1 - s;
    W_norms = vecnorm(W, 2, 2);  % 每一行的L2范数
    loss3 = beta * sum(one_minus_s .* (W_norms .^ r1));

    % 第四项：gamma * sum((1 - s_i) * g_i^r2)
    loss4 = gamma * sum(one_minus_s .* (g .^ r2));

    % 总损失
    loss = loss1 + loss2 + loss3 + loss4;
end
