function [NIFL, NIFLN] = ccomputeNIFL(train_data,train_label, NHF,NHL)
% 计算标签相似度矩阵 NIFL 及其归一化版本 NIFLN
%
% 输入：
%   - train_data：n × m 的多标签矩阵，每列是一个特征
%   - train_label：n × l 的多标签矩阵，每列是一个标签
%   - NHF：m × 1 的信息量向量（特征）
%   - NHL：l × 1 的信息量向量（标签）
%
% 输出：
%   - NILL：m × l 的特征-标签相似度矩阵
%   - NILLN：m × l 的归一化特征-标签相似度矩阵

    [~, m] = size(train_data);
    [~, l] = size(train_label);
    NIFL = zeros(m, l);
    NIFLN = zeros(m, l);

    for i = 1:m
        if NHF(i) == 0, continue; end
        fi = train_data(:, i);
        for j = 1:l
            if NHL(j) == 0, continue; end
            lj = train_label(:, j);
            sim = cNIFtoL(fi, lj);
            NIFL(i, j) = sim;
            NIFLN(i, j) = 2 * sim / (NHF(i) + NHL(j));
        end
    end
end