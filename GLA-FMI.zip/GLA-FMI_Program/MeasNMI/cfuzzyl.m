function NERT = cfuzzyl(label)
% 构造一个模糊等价矩阵：标签不一样的样本对设为0，其它为1
label = label(:);               % 转成列向量以统一格式
NERT = double(label == label'); % 逻辑矩阵转 double，自动得到对称结构
end