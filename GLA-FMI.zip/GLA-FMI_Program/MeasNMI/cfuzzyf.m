function NERT = cfuzzyf(feature)
    n = length(feature);
    sigma = var(feature, 1);

    if sigma == 0
        NERT = ones(n);  % 所有元素相同，相似度为1
    else
        diffMat = feature - feature';          % 构造差值矩阵
        distSq = diffMat .^ 2;                 % 计算平方差
        NERT = exp(-distSq / (2 * sigma));     % 高斯核函数
    end
end
