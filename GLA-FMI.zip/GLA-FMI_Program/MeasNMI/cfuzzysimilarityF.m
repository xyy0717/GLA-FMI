function Similarity = cfuzzysimilarityF(Feature)
[m,n]=size(Feature);
Similarity = ones(m);
for i=1:n
    NERT=cfuzzyf(Feature(:,i));
    Similarity = min(Similarity,NERT);
end

