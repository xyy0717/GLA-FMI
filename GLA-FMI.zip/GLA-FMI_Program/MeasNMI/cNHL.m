function NH = cNHL(Label)
%%仅支持单个特征输入
[n,~]=size(Label);
NERT=cfuzzysimilarityL(Label);
row_L1 = sum(abs(NERT), 2);        % 每一行的 L1 范数，即 |NERT_{i·}|_1
log_vals = log(row_L1 / n);       % 计算 log(|NERT_{i·}|_1 / n)
NH = -mean(log_vals);         % 取负的平均值