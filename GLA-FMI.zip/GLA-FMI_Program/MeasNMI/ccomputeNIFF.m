function [NIFF, NIFFN] = ccomputeNIFF(train_data, NHF)
% 计算特征冗余度矩阵 NILL 及其归一化版本 NILLN
%
% 输入：
%   - train_data：n × m 的多标签矩阵，每列是一个特征
%   - NHF：m × l 的信息量向量
%
% 输出：
%   - NIFF：m × m 的标签相似度矩阵
%   - NIFFN：m × m 的归一化标签相似度矩阵

    m = size(train_data, 2);
    NIFF = diag(NHF);       % 对角线赋值为 NHF
    NIFFN = eye(m);         % 对角线为 1，其它初始化为 0

    for i = 1:m
        if NHF(i) == 0, continue; end
        fi = train_data(:, i);
        for j = i+1:m
            if NHF(j) == 0, continue; end
            fj = train_data(:, j);
            sim = cNIFtoF(fi, fj);
            NIFF(i, j) = sim; NIFF(j, i) = sim;
            normSim = 2 * sim / (NHF(i) + NHF(j));
            NIFFN(i, j) = normSim; NIFFN(j, i) = normSim;
        end
    end
end