function Similarity = cfuzzysimilarityL(Label)
[m,n]=size(Label);
Similarity = ones(m);

for i=1:n
    NERT=cfuzzyl(Label(:,i));
    Similarity = min(Similarity,NERT);
end

