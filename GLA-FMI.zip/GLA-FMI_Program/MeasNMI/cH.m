function NH = cH(NERT)
n = size(NERT,1);
row_L1 = sum(abs(NERT), 2);        % 每一行的 L1 范数，即 |NERT_{i·}|_1
log_vals = log(row_L1 / n);       % 计算 log(|NERT_{i·}|_1 / n)
NH = -mean(log_vals);         % 取负的平均值