function [NILL, NILLN] = ccomputeNILL(train_label, NHL)
% 计算标签相似度矩阵 NILL 及其归一化版本 NILLN
%
% 输入：
%   - train_label：n × l 的多标签矩阵，每列是一个标签
%   - NHL：n × l 的信息量向量
%
% 输出：
%   - NILL：l × l 的标签相似度矩阵
%   - NILLN：l × l 的归一化标签相似度矩阵

    l = size(train_label, 2);
    NILL = diag(NHL);       % 将 NHL 作为对角线
    NILLN = eye(l);         % 对角线为 1

    for i = 1:l
        if NHL(i) == 0, continue; end
        li = train_label(:, i);
        for j = i+1:l
            if NHL(j) == 0, continue; end
            lj = train_label(:, j);
            sim = cNILtoL(li, lj);   % 计算标签相似度
            NILL(i, j) = sim; NILL(j, i) = sim;
            normSim = 2 * sim / (NHL(i) + NHL(j));
            NILLN(i, j) = normSim; NILLN(j, i) = normSim;
        end
    end
end